Read Me; 

Language pack made by me, Gus. NOT LEGAL and probably will never be. 

English (US) - English with Ukrainian fletching table, brewing stand, shield, some axes and pickaxes, etc.
English (Canada) - Perfect custom language (HIGHLY ILLEGAL). # for explosives, shield, tools, bucket, f&s, carrots, ingots, and
$ for fletching table, brewing stand, and golden tools only

CREDITS: 
- Silverr for letting me borrow his pack and build on the .lang file for this
- Rowl for the idea of using Ukrainian
- @2econdairy on twitter for the custom language idea