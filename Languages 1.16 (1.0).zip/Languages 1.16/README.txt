Read Me; 

Language pack made by me, Gus. NOT LEGAL and probably will never be. 

English (US) - English with a few Bosnian names for book crafting.
English (Canada) - Perfect custom language (HIGHLY ILLEGAL). # for explosives, $ for tools, ingots, shield, F&S, and bucket.

CREDITS: 
- Silverr for letting me borrow his pack and build on the .lang file for this
- Fyroah (i think) for the Bosnian crafting language
- Rowl for the idea of using Ukrainian
- @2econdairy on twitter for the custom language idea